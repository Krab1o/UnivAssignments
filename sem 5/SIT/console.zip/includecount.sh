#! /bin/bash
grep "#include" $1 | wc -l
