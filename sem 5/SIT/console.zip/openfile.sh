#! /bin/bash
vim $(find ~ -type f | fzf)
